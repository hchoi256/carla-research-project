## inspired by tutorial https://debuggercafe.com/semantic-segmentation-using-pytorch-fcn-resnet/
import torchvision.transforms as transforms
import cv2
import numpy as np
import numpy
import torch
# from google.colab.patches import cv2_imshow

import torchvision

from PIL import Image


label_map = [
               (0, 0, 0),  # background
               (128, 0, 0), # aeroplane
               (0, 128, 0), # bicycle
               (128, 128, 0), # bird
               (0, 0, 128), # boat
               (128, 0, 128), # bottle
               (0, 128, 128), # bus 
               (128, 128, 128), # car
               (64, 0, 0), # cat
               (192, 0, 0), # chair
               (64, 128, 0), # cow
               (192, 128, 0), # dining table
               (64, 0, 128), # dog
               (192, 0, 128), # horse
               (64, 128, 128), # motorbike
               (192, 128, 128), # person
               (0, 64, 0), # potted plant
               (128, 64, 0), # sheep
               (0, 192, 0), # sofa
               (128, 192, 0), # train
               (0, 64, 128) # tv/monitor
]


# define the torchvision image transforms
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])


def get_segment_labels(image, model, device):
    # transform the image to tensor and load into computation device
    image = transform(image).to(device)
    image = image.unsqueeze(0)
    outputs = model(image)
    return outputs


def draw_segmentation_map(outputs):
    labels = torch.argmax(outputs.squeeze(), dim=0).detach().cpu().numpy()
    red_map = np.zeros_like(labels).astype(np.uint8)
    green_map = np.zeros_like(labels).astype(np.uint8)
    blue_map = np.zeros_like(labels).astype(np.uint8)
    
    for label_num in range(0, len(label_map)):
        index = labels == label_num
        red_map[index] = np.array(label_map)[label_num, 0]
        green_map[index] = np.array(label_map)[label_num, 1]
        blue_map[index] = np.array(label_map)[label_num, 2]
        
    segmented_image = np.stack([red_map, green_map, blue_map], axis=2)
    return segmented_image


def image_overlay(image, segmented_image):
    alpha = 0.6 # how much transparency to apply
    beta = 1 - alpha # alpha + beta should equal 1
    gamma = 0 # scalar added to each sum
    image = np.array(image)
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    segmented_image = cv2.cvtColor(segmented_image, cv2.COLOR_RGB2BGR)
    cv2.addWeighted(segmented_image, alpha, image, beta, gamma, image)
    return image


# download or load the model from disk
model = torchvision.models.segmentation.fcn_resnet50(pretrained=True)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model.eval().to(device)

# read the image
image_file = 'inputs/street7.jpg'
image = Image.open(image_file)

print(np.shape(image))
# do forward pass and get the output dictionary
outputs = get_segment_labels(image, model, device)
# get the data from the `out` key
outputs = outputs['out']
segmented_image = draw_segmentation_map(outputs)


final_image = image_overlay(image, segmented_image)
save_name = image_file.split('/')[1].split('.')[0]
# show the segmented image and save to disk
# cv2.imshow('Segmented image', final_image)
cv2.waitKey(0)
cv2.imwrite(f"outputs/{save_name}.jpg", final_image)


######################## ANSWERS #############################
# Model used: RESNET 50. For this project, we chose to work with Resnet 50 to implement semantic segmentation for Carla objects. 
# The model is well-known for its high performance in segmentation. For evaluation, we used the pre-trained model that had trained 
# the COCO dataset, then performed segmentation tasks in the Carla simulator with the weights. 

# Evaluation Metrics: Currently, we are using a manual evaluation visual inspection. But we expect to develop another model to compare
#  with our Resnet model.

# Potential Improvements & Solution: Our resulting images show segmentation errors, with the interior of one segmented object 
# being detected as another. To resolve this issue, we expect to use Transformers to recognize objects as one and provide more context
#  information.